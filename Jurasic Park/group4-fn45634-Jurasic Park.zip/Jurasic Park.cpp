#include"input.hpp"
int main()
{
    input().Begin();
}

