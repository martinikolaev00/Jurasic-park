var class_h_q =
[
    [ "addcage", "class_h_q.html#ad58f20a8eff8ebc72128f1ab604bfe47", null ],
    [ "adddinoincage", "class_h_q.html#a5f386f17195b746844781252702eeebf", null ],
    [ "adddinosour", "class_h_q.html#a9772bafe11bc5592d36b360284cb74ad", null ],
    [ "checkforcage", "class_h_q.html#a701605fd07d2f4a9b3a14b5f4a60d72e", null ],
    [ "checkfordino", "class_h_q.html#a99341370a6357b648cd1def298218ca1", null ],
    [ "createcage", "class_h_q.html#a5e1dc41082772cdb77d9d99698f6d295", null ],
    [ "deserialize", "class_h_q.html#a52649e77a5b065f029eafd598aab23e9", null ],
    [ "feed", "class_h_q.html#aa1cdd2b5fdc607b5a1f637d989df764e", null ],
    [ "isdinoincage", "class_h_q.html#a6811338b651928d6644820dad2876724", null ],
    [ "max", "class_h_q.html#a9acc2aa9c9e0ce9a3e2d7a2970c592b3", null ],
    [ "removedino", "class_h_q.html#af7f9357cc84314f1184b0ae1e77c29f0", null ],
    [ "serialize", "class_h_q.html#a83c3a807d0a3dfbbc6dec46978c7ff0c", null ],
    [ "stockfood", "class_h_q.html#a23a4c1a8a2db57c897aaea6b183f355a", null ]
];