var classinput =
[
    [ "adddinosour", "classinput.html#a6268a15689b89f189adb62e87d9b613c", null ],
    [ "Begin", "classinput.html#a8579c80aa41ad7c7d9d955368d140a22", null ],
    [ "buildcage", "classinput.html#a0326a426ece1faebdd833999df63e62a", null ],
    [ "checkforcage", "classinput.html#a4a38d862632abd492e2f5ff1e1d13971", null ],
    [ "feed", "classinput.html#a6ff4ed544f1ff4c132483eeb75d66c6e", null ],
    [ "getcommand", "classinput.html#a4eea2f5f2ed0529564223060c8c9affc", null ],
    [ "Input", "classinput.html#af6987a1ccc9b5931a58906f19583427c", null ],
    [ "load", "classinput.html#af85e957582ff49b8efe17384bdfae1d7", null ],
    [ "menu", "classinput.html#aecd4ecfced6ce24441eead51dcf4456d", null ],
    [ "removedinosour", "classinput.html#a904d5c7fb1705df286965876e8ad157f", null ],
    [ "save", "classinput.html#a90a60274b828f30fe81addc4c25c424b", null ],
    [ "stockfood", "classinput.html#ae5b06b47e3b2e59991cd4213af4496e5", null ],
    [ "switchmenu", "classinput.html#adcd0a8a0f74af63605b8be11b781a47c", null ]
];