var searchData=
[
  ['vegitarian_92',['Vegitarian',['../_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba3fbe32fdf9c05b29d1b948cdb1043d00',1,'Dinasour.h']]]
];
