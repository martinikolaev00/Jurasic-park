var indexSectionsWithContent =
{
  0: "abcdefghijlmoprstuvw~",
  1: "cdhi",
  2: "cdhij",
  3: "abcdfghilmorst~",
  4: "cms",
  5: "cfgps",
  6: "abcefgjmstuvw",
  7: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends"
};

