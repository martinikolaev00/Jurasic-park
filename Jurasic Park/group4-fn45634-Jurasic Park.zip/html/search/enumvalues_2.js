var searchData=
[
  ['carnivorous_185',['Carnivorous',['../_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba863f8aac4b04790546835be316fc3ead',1,'Dinasour.h']]],
  ['chalk_186',['Chalk',['../_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447a56c377d856b14486380e096540fa59da',1,'Dinasour.h']]]
];
