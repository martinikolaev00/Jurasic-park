var searchData=
[
  ['triassic_197',['Triassic',['../_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447a151669a8ff5f9b8a538096fd1f7a1f1e',1,'Dinasour.h']]]
];
