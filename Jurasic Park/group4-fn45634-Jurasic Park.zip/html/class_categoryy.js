var class_categoryy =
[
    [ "Categoryy", "class_categoryy.html#a983b3dd7696a487add17535d4ad2a30f", null ],
    [ "Categoryy", "class_categoryy.html#a102d7cc02b66b99f1f3015757cd7e2dd", null ],
    [ "Categoryy", "class_categoryy.html#a7200913cde08933cc1a8adeb955992a7", null ],
    [ "~Categoryy", "class_categoryy.html#aef3c1712576864d2c529a4d05ea6054d", null ],
    [ "checktype", "class_categoryy.html#ad91b6cc9458ed38892118407912b4453", null ],
    [ "deserialize", "class_categoryy.html#acb0268e107a5684f0f4993c514590778", null ],
    [ "getcategory", "class_categoryy.html#aaa9d090e640edd322822e1c6b7c41a1b", null ],
    [ "getnuminenum", "class_categoryy.html#ac8710226aea982f3c565d2911e7e1002", null ],
    [ "gettype", "class_categoryy.html#af0f5fb2c80b107e5c8ef77f9c2db2763", null ],
    [ "operator=", "class_categoryy.html#adbe46a34c8ce603b2c00cf7b8a21f7ca", null ],
    [ "operator==", "class_categoryy.html#a00557048fe3bf50ce6db9522b771593f", null ],
    [ "serialize", "class_categoryy.html#ab383641f82223745c7f65437d22540ee", null ]
];