var class_dinasour =
[
    [ "Dinasour", "class_dinasour.html#a93aa6c6fba271083925916eee29eb241", null ],
    [ "Dinasour", "class_dinasour.html#a01d61a1401f5b0ed21388a76ab410cd4", null ],
    [ "Dinasour", "class_dinasour.html#a2f79bca327140eabd1c7535eb86b3aed", null ],
    [ "~Dinasour", "class_dinasour.html#a4e049efdfe30418753c06fd38e3b7594", null ],
    [ "deserialize", "class_dinasour.html#a081cc287816d47619a1e5355bdaf1a06", null ],
    [ "getcategory", "class_dinasour.html#abc7480844779f917b18ede546d1cccfe", null ],
    [ "getfood", "class_dinasour.html#abaee269f24f763a9c6f6be922a1ddcd4", null ],
    [ "getname", "class_dinasour.html#a39e1cc89bf2e5522b74d0cffee61e049", null ],
    [ "getperiod", "class_dinasour.html#a817a7c1686daa963e50bc75fb7299e80", null ],
    [ "gettype", "class_dinasour.html#ad6e021aa8a12f23ed9f0cb7fb904f70d", null ],
    [ "operator=", "class_dinasour.html#a7fb41f7abf6980952b6ece95617f553e", null ],
    [ "operator==", "class_dinasour.html#a68a9fa6babdbc02afdf116475250a691", null ],
    [ "serialize", "class_dinasour.html#ac64f05621475713c474570e8c01c36ee", null ]
];