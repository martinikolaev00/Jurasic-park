var _commands_8hpp =
[
    [ "adddinasour", "_commands_8hpp.html#ab5ed5e4ef008f7078bb941645da45741", null ],
    [ "Begin", "_commands_8hpp.html#a1149e1e7da0129dfcc98c047dcdf9c79", null ],
    [ "buildcage", "_commands_8hpp.html#a9150aecf2041d46fc4b79a033bf6ed20", null ],
    [ "checkforcage", "_commands_8hpp.html#a498abdd149e0996729e4fb4ac5f3c1ee", null ],
    [ "help", "_commands_8hpp.html#a97ee70a8770dc30d06c744b24eb2fcfc", null ],
    [ "Input", "_commands_8hpp.html#a811b7cf72f3317200595c3a353431608", null ],
    [ "menu", "_commands_8hpp.html#a2a0e843767aeea4f433a28b9c54f573a", null ],
    [ "removedinasour", "_commands_8hpp.html#a7921cd1dcd0514d7310c7f3a1674a3e1", null ],
    [ "stockfood", "_commands_8hpp.html#a97ca7360acf0b0fc6e9acee1ef20f288", null ],
    [ "switchmenu", "_commands_8hpp.html#a0ee2b85529a3579b7d47be02a2f7bf63", null ],
    [ "type", "_commands_8hpp.html#ac0e56df4d0aeb6e6ae57932330de7457", null ]
];