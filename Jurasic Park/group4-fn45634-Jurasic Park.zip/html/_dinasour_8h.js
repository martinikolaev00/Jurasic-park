var _dinasour_8h =
[
    [ "Dinasour", "class_dinasour.html", "class_dinasour" ],
    [ "Category", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccb", [
      [ "Unknown", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Vegitarian", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba3fbe32fdf9c05b29d1b948cdb1043d00", null ],
      [ "Carnivorous", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba863f8aac4b04790546835be316fc3ead", null ],
      [ "Aqueous", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccbaa6321bc893937f08e004b7f96f8a73a9", null ],
      [ "Flying", "_dinasour_8h.html#a9ca8f05608edcbf85ab6c2c85a439ccba444733081a578880ba8a563d3c59d22d", null ]
    ] ],
    [ "Food", "_dinasour_8h.html#aa2cc7a8bd317f0cac42b1d090f78470b", [
      [ "Unknown", "_dinasour_8h.html#aa2cc7a8bd317f0cac42b1d090f78470ba88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Grass", "_dinasour_8h.html#aa2cc7a8bd317f0cac42b1d090f78470baaac9a63596f76a62bb9f61a5dd7c0d25", null ],
      [ "Meat", "_dinasour_8h.html#aa2cc7a8bd317f0cac42b1d090f78470bae4b662d3892f8c0c86801919f979467f", null ],
      [ "Fish", "_dinasour_8h.html#aa2cc7a8bd317f0cac42b1d090f78470ba071642fa72ba780ee90ed36350d82745", null ]
    ] ],
    [ "Gender", "_dinasour_8h.html#a3667e3c5ec056737c8789615a989324f", [
      [ "Unknown", "_dinasour_8h.html#a3667e3c5ec056737c8789615a989324fa88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Male", "_dinasour_8h.html#a3667e3c5ec056737c8789615a989324fa63889cfb9d3cbe05d1bd2be5cc9953fd", null ],
      [ "Female", "_dinasour_8h.html#a3667e3c5ec056737c8789615a989324fab719ce180ec7bd9641fece2f920f4817", null ]
    ] ],
    [ "Period", "_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447", [
      [ "Unknown", "_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Triassic", "_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447a151669a8ff5f9b8a538096fd1f7a1f1e", null ],
      [ "Chalk", "_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447a56c377d856b14486380e096540fa59da", null ],
      [ "Jurassic", "_dinasour_8h.html#a0b20dd0178c234cab8478b82f8d1c447ab7d583f9636b1d2ae060aa772e04bb1e", null ]
    ] ]
];