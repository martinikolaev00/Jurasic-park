var _cage_8hpp =
[
    [ "Cage", "class_cage.html", "class_cage" ],
    [ "Climate", "_cage_8hpp.html#adc9fee6ad7fde07167b697ab6984f5d5", [
      [ "Unknown", "_cage_8hpp.html#adc9fee6ad7fde07167b697ab6984f5d5a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Earth", "_cage_8hpp.html#adc9fee6ad7fde07167b697ab6984f5d5a5cdd21c97f86686cc505e02fd32a7523", null ],
      [ "Water", "_cage_8hpp.html#adc9fee6ad7fde07167b697ab6984f5d5a27634ff8002b12e75d98e07ccd005d18", null ],
      [ "Air", "_cage_8hpp.html#adc9fee6ad7fde07167b697ab6984f5d5a71c546fa61f3964d72bdf25223b78669", null ]
    ] ],
    [ "Size", "_cage_8hpp.html#a1c40db1d9b56c27240e420765695f1c4", [
      [ "Unknown", "_cage_8hpp.html#a1c40db1d9b56c27240e420765695f1c4a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Small", "_cage_8hpp.html#a1c40db1d9b56c27240e420765695f1c4a2660064e68655415da2628c2ae2f7592", null ],
      [ "Medium", "_cage_8hpp.html#a1c40db1d9b56c27240e420765695f1c4a87f8a6ab85c9ced3702b4ea641ad4bb5", null ],
      [ "Big", "_cage_8hpp.html#a1c40db1d9b56c27240e420765695f1c4ad491538da818a2ba11a3195ba035cfd3", null ]
    ] ]
];