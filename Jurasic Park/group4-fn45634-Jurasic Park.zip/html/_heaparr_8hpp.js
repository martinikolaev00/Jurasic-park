var _heaparr_8hpp =
[
    [ "Heaparr", "class_heaparr.html", "class_heaparr" ],
    [ "startersize", "_heaparr_8hpp.html#a498ba560f043ee079f8fea06aca2a73c", null ]
];